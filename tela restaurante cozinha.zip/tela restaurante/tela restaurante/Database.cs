using MySqlConnector;

namespace tela_restaurante
{
    public static class Database
    {
       
        private const string ConnectionString =
            "Server=10.1.20.242;Port=3306;Database=restaurante;User ID=joao.bernardo;Password= JoaA@6429;";

        public static MySqlConnection CriarConexao()
        {
            return new MySqlConnection(ConnectionString);
        }
    }
}
