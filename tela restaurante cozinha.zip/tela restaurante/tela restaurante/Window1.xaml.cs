using MySqlConnector;
using System.Data;
using System.Windows;

namespace tela_restaurante
{
    public partial class Window1 : Window
    {
        private string conexao = "Server=10.1.20.242;Port=3306;Database=restaurante;User ID= joao.bernardo;Password=JoaA@6429;";

        public Window1()
        {
            InitializeComponent();
            CarregarPedidos();
        }

        private void CarregarPedidos()
        {
            try
            {
                using (MySqlConnection banco = new MySqlConnection(conexao))
                {
                    banco.Open();

                    string sql = @"SELECT
                                       id AS Codigo,
                                       mesa AS Mesa,
                                       pedido AS Pedido,
                                       observacao AS Observacao,
                                       data_pedido AS Horario
                                   FROM pedidos
                                   ORDER BY id DESC";

                    MySqlDataAdapter adaptador = new MySqlDataAdapter(sql, banco);
                    DataTable tabela = new DataTable();
                    adaptador.Fill(tabela);

                    GridPedidos.ItemsSource = tabela.DefaultView;
                }
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Erro ao carregar os pedidos:\n" + ex.Message);
            }
        }

        private void BtnAtualizar_Click(object sender, RoutedEventArgs e)
        {
            CarregarPedidos();
        }
    }
}
