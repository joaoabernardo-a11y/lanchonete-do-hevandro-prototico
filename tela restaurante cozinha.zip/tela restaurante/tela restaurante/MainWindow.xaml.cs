using MySqlConnector;
using System.Windows;

namespace tela_restaurante
{
    public partial class MainWindow : Window
    {
        private string conexao = "Server=10.1.20.242;Port=3306;Database=restaurante;User ID= joao.bernardo;Password=JoaA@6429;";

        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnSalvar_Click(object sender, RoutedEventArgs e)
        {
            if (!int.TryParse(TxtMesa.Text, out int mesa))
            {
                MessageBox.Show("Digite o número da mesa.");
                return;
            }

            if (string.IsNullOrWhiteSpace(TxtPedido.Text))
            {
                MessageBox.Show("Digite o pedido.");
                return;
            }

            try
            {
                using (MySqlConnection banco = new MySqlConnection(conexao))
                {
                    banco.Open();

                    string sql = "INSERT INTO pedidos (mesa, pedido, observacao) VALUES (@mesa, @pedido, @observacao)";

                    using (MySqlCommand comando = new MySqlCommand(sql, banco))
                    {
                        comando.Parameters.AddWithValue("@mesa", mesa);
                        comando.Parameters.AddWithValue("@pedido", TxtPedido.Text);
                        comando.Parameters.AddWithValue("@observacao", TxtObservacao.Text);
                        comando.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Pedido salvo com sucesso.");

                TxtMesa.Clear();
                TxtPedido.Clear();
                TxtObservacao.Clear();
                TxtMesa.Focus();
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Erro ao salvar no banco:\n" + ex.Message);
            }
        }

        private void BtnAbrirCozinha_Click(object sender, RoutedEventArgs e)
        {
            Window1 cozinha = new Window1();
            cozinha.Show();
        }
    }
}
