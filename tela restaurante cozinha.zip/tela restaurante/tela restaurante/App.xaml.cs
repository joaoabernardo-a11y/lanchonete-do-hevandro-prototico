using System.Windows;

namespace tela_restaurante
{
    public partial class App : Application
    {
    }
}
