
DROP DATABASE IF EXISTS restaurante;
CREATE DATABASE restaurante;
USE restaurante;

CREATE TABLE pedidos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    mesa INT NOT NULL,
    pedido VARCHAR(500) NOT NULL,
    observacao VARCHAR(255),
    data_pedido DATETIME DEFAULT CURRENT_TIMESTAMP
);


SELECT * FROM pedidos;